'use strict'

var User = require('../models/userModel');
var moment = require('moment');
var bcrypt = require('bcrypt-nodejs');
var mongoosePaginate = require('mongoose-pagination');
var multipart = require('connect-multiparty');
var md_upload = multipart({uploadDir : './uploads/data'});
var jwt = require('../services/jwt')

/**
 * Registrar un usuario en el sistema de Snip
 * adicional : Crear coleccion de adicionales y home
 * ---------------------------------------------
 * @param {*} req : La petición que me hace el cliente
 * @param {*} res : La respuesta que le envío al cliente
 */
function createUser(req, res) {
    var user = new User();
    var params = req.body;
    if (params.name && params.surname &&
        params.nick && params.email && params.password && params.status) {
        user.name = params.name;
        user.surname = params.surname;
        user.nick = params.nick.toLowerCase();
        user.role = params.role,
        user.email = params.email.toLowerCase();
        user.status = params.status;
        user.created_at = moment().unix();
        user.updated_at = moment().unix();
        // -Controlador de usuarios duplicados
        User.find({
            $or: [
                { email: user.email }, // Evitando que el email se repita
                { nick: user.nick } // Evitando que el usuario se repita
            ]
        }).exec((err, users) => {
            if (err) return res.status(500).send({response: 'No se ha podido establecer conexión con el servidor.' })
            if (users && users.length >= 1) {
                // Se encontró un usuario que ya existe.
                return res.status(403).send({response: 'El usuario que estás intentado registrar ya existe.' });
            } else {
                // -Encripto la contraseña del usuario y hago el proceso de guardado.
                bcrypt.hash(params.password, null, null, (err, hash) => {
                    user.password = hash
                    user.save((err, userStored) => {
                        if (err) return res.status(500).send({response: 'Error al guardar el usuario', err })
                        if (userStored) {
                            // ..Devuelve el usuario almacenado correctamente.
                            userStored.password = undefined
                            return res.status(200).send({response: userStored});
                        } else {
                            return res.status(400).send({response: 'No se ha podido registrar el usuario' })
                        }
                    })
                })
            }
        })
    }
    else {
        res.status(403).send({
            code: '403',
            response: 'Por favor rellene todos los campos.'
        })
    }
}



/**
 * Obtener la información de un usuario
 * ---------------------------------------------
 * @param {*} req : La petición que me hace el cliente
 * @param {*} res : La respuesta que le envío al cliente
 */
function readUser(req, res) {
    var userId = req.params.id;
    User.findById(userId).exec((err, response) => {
        if (err) return res.status(500).send({ code: '500', response: 'error al leer el usuario -- ' + err })
        if (!response) return res.status(404).send({ code: '404', response: 'no se ha encontrado el usuario' });
        return res.status(200).send({ code: '200', response })
    })
}




/**
 * Actualizar un usuario en Snip
 * ---------------------------------------------
 * @param {*} req : La petición que me hace el cliente
 * @param {*} res : La respuesta que le envío al cliente
 */
function updateUser(req, res) {
    var userId = req.params.id ? req.params.id : req.user.sub;
    var params = req.body;
    User.findByIdAndUpdate(userId, params, { new: true }, (err, response) => {
        if (err) return res.status(500).send({ code: '500', response: 'error al actualizar el usuario ' + err })
        if (!response) return res.status(404).send({ code: '404', response: 'no se ha encontrado el usuario' });
        return res.status(200).send({ code: '200', response })
    })
}



/**
 * Eliminar un usuario en Snip
 * ---------------------------------------------
 * @param {*} req : La petición que me hace el cliente
 * @param {*} res : La respuesta que le envío al cliente
 */
function deleteUser(req, res) {
    var userId = req.params.id;
    User.findByIdAndRemove(userId, (err, response) => {
        if (err) return res.status(500).send({ message: 'error al eliminar el usuario ' + err })
        if (!response) return res.status(404).send({ message: 'no se ha encontrado el usuario' });
        return res.status(200).send({ response: "El usuario se a eliminado correctamente" })
    })
}




/**
 * Hacer un listado de los usuarios
 * ---------------------------------------------
 * @param {*} req : La petición que me hace el cliente
 * @param {*} res : La respuesta que le envío al cliente
 */
function listUsers(req, res) {
    var page = 1
    var itemsPerPage = 10;
    if (req.params.page) {
        page = req.params.page
    }
    User.find().paginate(page, itemsPerPage, (err, response) => {
        if (err) return res.status(500).send({ response: 'error al listar los usuarios -- ' + err })
        if (!response) return res.status(404).send({ response: 'No se ha encontrado el usuario' });
        return res.status(200).send({ response })
    })
}






/**
 * Método para loguear los usuarios
 * ---------------------------------------------
 * @param {*} req : La petición que me hace el cliente 
 * @param {*} res : La respuesta que le envío al cliente
 */
function loginUser(req, res) {
    var params = req.body;
    var email = params.email;
    var password = params.password;

    // -Verificando que el usuario exista dentro del sistema
    User.findOne({
        $or: [
            { email: email }, // Verifica que exista el usuario por mail 
            { nick: email } // Verifica que exista el usuario por nick
        ]
    })
        .exec((err, user) => {
            if (err) return res.status(500).send({ code: 'not_found', message: 'Error al intentar buscar el usuario.' })
            if (user) {
                bcrypt.compare(password, user.password, (err, check)=>{
                    if(check){
                        if(params.token){
                            // !Generar y devolver el token
                            return res.status(200).send({
                                token : jwt.createToken(user)
                            })
                        }else{
                            // !Devuelve los datos del usuario logueado
                            user.password = undefined
                            return res.status(200).send({user})
                        }
                    }
                    else
                    {
                        return res.status(404).send({code : 'err_password' , message : 'La contraseña es incorrecta'})
                    }
                })
            }
            else {
                return res.status(404).send({ code: 'not_found', message: 'El usuario no existe.' })
            }
        })
}



// -Exportando los métodos del controlador
module.exports = {
    createUser,
    readUser,
    updateUser,
    deleteUser,
    listUsers,
    loginUser
}