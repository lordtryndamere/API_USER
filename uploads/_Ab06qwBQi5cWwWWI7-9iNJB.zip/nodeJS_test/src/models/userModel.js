'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// -Modelo de usuarios
var UserSchema = Schema({
    name            : String,
    surname         : String,
    nick            : String,
    email           : String,
    role            : String,
    token           : Boolean,
    password        : String,
    status          : String,
    created_at      : String,
    updated_at      : String
})

module.exports = mongoose.model('User' , UserSchema)