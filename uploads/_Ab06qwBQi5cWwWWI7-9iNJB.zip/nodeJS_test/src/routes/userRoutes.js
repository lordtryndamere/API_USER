'use strict'

var express = require('express');
var UserController = require('../controllers/userController');
var md_auth = require('../middlewares/authenticated');
var api = express.Router();


// -Definiendo rutas
api.post('/create' , UserController.createUser);
api.get('/:id' , UserController.readUser);
api.put('/:id' , UserController.updateUser);
api.delete('/:id' , md_auth.auth, UserController.deleteUser);
api.post('/login' , UserController.loginUser);
api.get('/list/:page?' ,md_auth.auth,  UserController.listUsers);
api.get('/get-image/:imageFile' ,md_auth.auth,  UserController.getImageFile);

// -Exportando el api
module.exports = api;