'use strict'


var jwt = require('jwt-simple');
var moment = require('moment');
var secret = 'mi_llave';

/**
 * Asegura que el usuario esté logueado correctamente y tenga un token
 * --------------------------------------------------------------------
 * @param {*} req : Datos que se reciben en la petición
 * @param {*} res : Respuesta que se envía
 * @param {*} next : Da el paso al controlador
 */
exports.auth = function(req, res, next){
    if(!req.headers.authorization){
        return res.status(403).send({message : 'NO tiene permisos de acceso'})
    }

    var token = req.headers.authorization.replace(/['"]+/g, '');

    // Decodificando el payload (todo el objeto tokenizado)
    try {
        var payload = jwt.decode(token, secret);
        if(payload.exp <= moment.unix()){
            return res.status(401).send({message : 'El token ha expirado, es necesario volverse a loguear'});
        }
    } catch (error) {
        return res.status(403).send({code : '403' , response : 'El token no es válido. ' + error});
    }

    req.user = payload;
    next();
}
