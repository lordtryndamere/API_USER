'use strict'

var mongoose = require('mongoose');
var app = require('./app');
var PORT = 2020;

// Conectar a la base de datos
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/DB', {useNewUrlParser : true, useUnifiedTopology: true})
.then(()=>{
    // Crear servidor
    app.listen(PORT, () => {
        console.log('Servidor corriendo port:' + PORT)
    })
    console.log('La comunicación con la base de datos fue exitosa!!')
})
.catch((err)=>{
    console.log(err)
})